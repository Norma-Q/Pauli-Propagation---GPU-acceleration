from __future__ import annotations

from pathlib import Path

from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CppExtension

HERE = Path(__file__).resolve().parent

setup(
    name="pps_tensor_backend",
    version="0.0.0",
    ext_modules=[
        CppExtension(
            name="src_tensor._pps_tensor_backend",
            sources=[str(HERE / "pps_tensor_backend.cpp")],
            extra_compile_args={"cxx": ["-O3"]},
        )
    ],
    cmdclass={"build_ext": BuildExtension},
)
