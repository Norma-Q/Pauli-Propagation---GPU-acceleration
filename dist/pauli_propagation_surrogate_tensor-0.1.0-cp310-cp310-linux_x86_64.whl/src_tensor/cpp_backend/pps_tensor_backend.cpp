#include <torch/extension.h>

#include <c10/util/Optional.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

namespace {

torch::Tensor popcount_u64(const torch::Tensor& x) {
  auto count = torch::zeros_like(x, torch::TensorOptions().dtype(torch::kInt64));
  for (int i = 0; i < 64; i++) {
    count = count + torch::bitwise_and(torch::bitwise_right_shift(x, i), 1);
  }
  return count;
}

torch::Tensor truncate_terms_mask(const torch::Tensor& x_mask, const torch::Tensor& z_mask, int64_t max_weight,
                                 int64_t max_xy) {
  auto weight = popcount_u64(x_mask | z_mask);
  auto xy = popcount_u64(x_mask);
  return (weight <= max_weight) & (xy <= max_xy);
}

torch::Tensor phase_sign_tensor(const torch::Tensor& x_mask, const torch::Tensor& z_mask, const torch::Tensor& gx_t,
                               const torch::Tensor& gz_t) {
  // Matches Python `_phase_sign_tensor`.
  auto pX = x_mask & (~z_mask);
  auto pY = x_mask & z_mask;
  auto pZ = (~x_mask) & z_mask;

  auto gX = gx_t & (~gz_t);
  auto gY = gx_t & gz_t;
  auto gZ = (~gx_t) & gz_t;

  auto cnt_xy = popcount_u64(pX & gY);
  auto cnt_zx = popcount_u64(pZ & gX);
  auto cnt_yz = popcount_u64(pY & gZ);
  auto cnt_yx = popcount_u64(pY & gX);
  auto cnt_xz = popcount_u64(pX & gZ);
  auto cnt_zy = popcount_u64(pZ & gY);

  auto s = (cnt_xy + cnt_zx + cnt_yz + 3 * (cnt_yx + cnt_xz + cnt_zy)) & 3;

  auto neg_one = -torch::ones_like(s, torch::TensorOptions().dtype(torch::kInt64));
  auto pos_one = torch::ones_like(s, torch::TensorOptions().dtype(torch::kInt64));
  auto zero = torch::zeros_like(s, torch::TensorOptions().dtype(torch::kInt64));
  return torch::where(s == 1, pos_one, torch::where(s == 3, neg_one, zero));
}

// Apply one Clifford gate (H/S/CNOT) to bitmask tensors.
static std::tuple<torch::Tensor, torch::Tensor, torch::Tensor> apply_clifford(const std::string& symbol,
                                                                              const std::vector<int64_t>& qubits,
                                                                              const torch::Tensor& x_mask,
                                                                              const torch::Tensor& z_mask,
                                                                              torch::ScalarType coeff_dtype) {
  auto device = x_mask.device();
  auto n = x_mask.numel();
  auto coeff_sign = torch::ones({n}, torch::TensorOptions().dtype(coeff_dtype).device(device));

  if (symbol == "H") {
    int64_t q = qubits.at(0);
    auto bit = torch::scalar_tensor(int64_t(1) << q, torch::TensorOptions().dtype(torch::kInt64).device(device));

    auto x_bit = (x_mask & bit).ne(0);
    auto z_bit = (z_mask & bit).ne(0);
    auto swap = x_bit ^ z_bit;

    auto new_x = x_mask ^ (swap.to(torch::kInt64) * bit);
    auto new_z = z_mask ^ (swap.to(torch::kInt64) * bit);

    auto y_mask = x_bit & z_bit;
    auto ones = torch::ones_like(coeff_sign);
    auto neg_ones = -torch::ones_like(coeff_sign);
    coeff_sign = coeff_sign * torch::where(y_mask, neg_ones, ones);
    return {new_x, new_z, coeff_sign};
  }

  if (symbol == "S") {
    int64_t q = qubits.at(0);
    auto bit = torch::scalar_tensor(int64_t(1) << q, torch::TensorOptions().dtype(torch::kInt64).device(device));

    auto x_bit = (x_mask & bit).ne(0);
    auto z_bit = (z_mask & bit).ne(0);

    auto x_only = x_bit & (~z_bit);
    auto y_mask = x_bit & z_bit;

    auto new_z = z_mask ^ (x_only.to(torch::kInt64) * bit);
    new_z = new_z ^ (y_mask.to(torch::kInt64) * bit);

    auto ones = torch::ones_like(coeff_sign);
    auto neg_ones = -torch::ones_like(coeff_sign);
    coeff_sign = coeff_sign * torch::where(y_mask, neg_ones, ones);
    return {x_mask, new_z, coeff_sign};
  }

  if (symbol == "CNOT") {
    int64_t c = qubits.at(0);
    int64_t t = qubits.at(1);
    auto bit_c = torch::scalar_tensor(int64_t(1) << c, torch::TensorOptions().dtype(torch::kInt64).device(device));
    auto bit_t = torch::scalar_tensor(int64_t(1) << t, torch::TensorOptions().dtype(torch::kInt64).device(device));

    auto xc = torch::bitwise_right_shift(torch::bitwise_and(x_mask, bit_c), c).to(torch::kInt64);
    auto zc = torch::bitwise_right_shift(torch::bitwise_and(z_mask, bit_c), c).to(torch::kInt64);
    auto xt = torch::bitwise_right_shift(torch::bitwise_and(x_mask, bit_t), t).to(torch::kInt64);
    auto zt = torch::bitwise_right_shift(torch::bitwise_and(z_mask, bit_t), t).to(torch::kInt64);

    auto c_idx = torch::bitwise_xor(xc + torch::bitwise_left_shift(zc, 1), zc);
    auto t_idx = torch::bitwise_xor(xt + torch::bitwise_left_shift(zt, 1), zt);
    auto lookup = t_idx + torch::bitwise_left_shift(c_idx, 2);

    // Tables as tensors (move to device so CUDA indexing works).
    auto opts_i64 = torch::TensorOptions().dtype(torch::kInt64).device(device);
    auto opts_f = torch::TensorOptions().dtype(coeff_dtype).device(device);

    auto tab0 = torch::tensor(std::vector<int64_t>({0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0}), opts_i64);
    auto tab1 = torch::tensor(std::vector<int64_t>({0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0}), opts_i64);
    auto tab2 = torch::tensor(std::vector<int64_t>({0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0}), opts_i64);
    auto tab3 = torch::tensor(std::vector<int64_t>({0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1}), opts_i64);
    auto tab4 = torch::tensor(std::vector<int64_t>({1, 1, 1, 1, 1, 1, 1, -1, 1, 1, -1, 1, 1, 1, 1, 1}), opts_f);

    auto nxc = tab0.index_select(0, lookup);
    auto nzc = tab1.index_select(0, lookup);
    auto nxt = tab2.index_select(0, lookup);
    auto nzt = tab3.index_select(0, lookup);
    auto sign = tab4.index_select(0, lookup);

    auto new_x = x_mask & (~bit_c) & (~bit_t);
    auto new_z = z_mask & (~bit_c) & (~bit_t);
        new_x = new_x | torch::bitwise_left_shift(nxc.to(torch::kInt64), c) |
          torch::bitwise_left_shift(nxt.to(torch::kInt64), t);
        new_z = new_z | torch::bitwise_left_shift(nzc.to(torch::kInt64), c) |
          torch::bitwise_left_shift(nzt.to(torch::kInt64), t);

    coeff_sign = coeff_sign * sign;
    return {new_x, new_z, coeff_sign};
  }

  // Unknown symbol: no-op
  return {x_mask, z_mask, coeff_sign};
}

static std::tuple<torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, torch::Tensor, py::object>
build_clifford_step_cpp(const std::string& symbol, const std::vector<int64_t>& qubits, const torch::Tensor& x_mask,
                        const torch::Tensor& z_mask, torch::ScalarType coeff_dtype, c10::optional<double> min_abs,
                        c10::optional<torch::Tensor> coeffs_cache, int64_t max_weight, int64_t max_xy) {
  auto n_in = x_mask.numel();

  auto [new_x0, new_z0, coeff_sign0] = apply_clifford(symbol, qubits, x_mask, z_mask, coeff_dtype);

  torch::Tensor new_x = new_x0;
  torch::Tensor new_z = new_z0;
  torch::Tensor coeff_sign = coeff_sign0;
  torch::Tensor col;

  torch::Tensor coeffs_prev;
  bool do_prune = min_abs.has_value();
  if (do_prune) {
    if (!coeffs_cache.has_value()) {
      throw std::runtime_error("min_abs provided but coeffs_cache is None");
    }
    coeffs_prev = coeffs_cache.value();
    auto pre_mask = (coeff_sign * coeffs_prev).abs() >= min_abs.value();
    auto idx = torch::nonzero(pre_mask).flatten();

    new_x = new_x.index_select(0, idx);
    new_z = new_z.index_select(0, idx);
    coeff_sign = coeff_sign.index_select(0, idx);
    col = idx.to(torch::kInt64);
  } else {
    col = torch::arange(n_in, torch::TensorOptions().dtype(torch::kInt64).device(x_mask.device()));
  }

  // Unique pairs via torch.unique (called from C++).
  auto keys = torch::stack({new_x, new_z}, 1);
  py::module torch_mod = py::module::import("torch");
  py::tuple uniq_out = torch_mod.attr("unique")(keys, py::arg("dim") = 0, py::arg("return_inverse") = true,
                                               py::arg("sorted") = false)
                          .cast<py::tuple>();
  torch::Tensor uniq = uniq_out[0].cast<torch::Tensor>();
  torch::Tensor inv = uniq_out[1].cast<torch::Tensor>();

  new_x = uniq.select(1, 0);
  new_z = uniq.select(1, 1);

  torch::Tensor row = inv.to(torch::kInt64);

  // Optional coeffs_cache update via scatter_add.
  py::object coeffs_cache_out = py::none();
  if (do_prune) {
    std::vector<int64_t> out_sz{new_x.numel()};
    auto out = torch::zeros(out_sz,
                            torch::TensorOptions().dtype(coeffs_prev.dtype()).device(coeffs_prev.device()));
    auto contrib = coeff_sign * coeffs_prev.index_select(0, col);
    out.index_add_(0, row, contrib);
    coeffs_cache_out = py::cast(out);
  }

  // Truncation and row filtering.
  auto mask = truncate_terms_mask(new_x, new_z, max_weight, max_xy);
  if (!(mask.all().item<bool>())) {
    auto keep_rows = mask.index_select(0, row);
    auto keep_idx = torch::nonzero(keep_rows).flatten();
    row = row.index_select(0, keep_idx);
    col = col.index_select(0, keep_idx);
    coeff_sign = coeff_sign.index_select(0, keep_idx);

    auto row_map = torch::cumsum(mask.to(torch::kInt64), 0) - 1;
    row = row_map.index_select(0, row);

    auto out_idx = torch::nonzero(mask).flatten();
    new_x = new_x.index_select(0, out_idx);
    new_z = new_z.index_select(0, out_idx);

    if (do_prune) {
      auto out_coeffs = coeffs_cache_out.cast<torch::Tensor>();
      out_coeffs = out_coeffs.index_select(0, out_idx);
      coeffs_cache_out = py::cast(out_coeffs);
    }
  }

  return {new_x, new_z, row, col, coeff_sign, coeffs_cache_out};
}

static std::tuple<torch::Tensor, torch::Tensor,
                  torch::Tensor, torch::Tensor, torch::Tensor,
                  torch::Tensor, torch::Tensor, torch::Tensor,
                  torch::Tensor, torch::Tensor, torch::Tensor,
                  py::object>
build_pauli_rotation_step_cpp(int64_t gx, int64_t gz, int64_t param_idx, const torch::Tensor& x_mask,
                             const torch::Tensor& z_mask, torch::ScalarType coeff_dtype, c10::optional<double> min_abs,
                             c10::optional<torch::Tensor> coeffs_cache, c10::optional<torch::Tensor> thetas_t,
                             int64_t max_weight, int64_t max_xy) {
  auto device = x_mask.device();
  auto n_in = x_mask.numel();

  auto gx_t = torch::scalar_tensor(gx, torch::TensorOptions().dtype(torch::kInt64).device(device));
  auto gz_t = torch::scalar_tensor(gz, torch::TensorOptions().dtype(torch::kInt64).device(device));

  auto symp = popcount_u64((x_mask & gz_t) ^ (z_mask & gx_t)) & 1;
  auto comm_mask = symp.eq(0);
  auto anti_mask = symp.eq(1);

  auto comm_idx = torch::nonzero(comm_mask).flatten().to(torch::kInt64);
  auto anti_idx = torch::nonzero(anti_mask).flatten().to(torch::kInt64);

  auto comm_x = x_mask.index_select(0, comm_idx);
  auto comm_z = z_mask.index_select(0, comm_idx);

  auto anti_x = x_mask.index_select(0, anti_idx);
  auto anti_z = z_mask.index_select(0, anti_idx);

  auto cos_x = anti_x;
  auto cos_z = anti_z;
  auto sin_x = anti_x ^ gx_t;
  auto sin_z = anti_z ^ gz_t;

  torch::Tensor cos_idx = anti_idx;
  torch::Tensor sin_idx = anti_idx;

  torch::Tensor sin_sign;
  torch::Tensor coeffs_prev;
  bool do_prune = min_abs.has_value();
  torch::Tensor cos_t;
  torch::Tensor sin_t;

  if (do_prune) {
    if (!coeffs_cache.has_value() || !thetas_t.has_value()) {
      throw std::runtime_error("min_abs provided but coeffs_cache/thetas_t is None");
    }
    coeffs_prev = coeffs_cache.value();

    auto theta = thetas_t.value().index({param_idx});
    cos_t = torch::cos(theta);
    sin_t = torch::sin(theta);

    auto mask_comm = coeffs_prev.index_select(0, comm_idx).abs() >= min_abs.value();
    auto mask_cos = (coeffs_prev.index_select(0, anti_idx) * cos_t).abs() >= min_abs.value();

    auto sin_sign_all = phase_sign_tensor(anti_x, anti_z, gx_t, gz_t).to(coeffs_prev.dtype());
    auto mask_sin = (coeffs_prev.index_select(0, anti_idx) * sin_t * sin_sign_all).abs() >= min_abs.value();

    auto comm_keep = torch::nonzero(mask_comm).flatten().to(torch::kInt64);
    comm_x = comm_x.index_select(0, comm_keep);
    comm_z = comm_z.index_select(0, comm_keep);
    comm_idx = comm_idx.index_select(0, comm_keep);

    auto cos_keep = torch::nonzero(mask_cos).flatten().to(torch::kInt64);
    cos_x = cos_x.index_select(0, cos_keep);
    cos_z = cos_z.index_select(0, cos_keep);
    cos_idx = anti_idx.index_select(0, cos_keep);

    auto sin_keep = torch::nonzero(mask_sin).flatten().to(torch::kInt64);
    sin_x = sin_x.index_select(0, sin_keep);
    sin_z = sin_z.index_select(0, sin_keep);
    sin_idx = anti_idx.index_select(0, sin_keep);
    sin_sign = sin_sign_all.index_select(0, sin_keep);
  } else {
    // Full sin sign (no prune)
    sin_sign = phase_sign_tensor(anti_x, anti_z, gx_t, gz_t);
  }

  // Unique pairs via torch.unique
  auto cat_x = torch::cat({comm_x, cos_x, sin_x}, 0);
  auto cat_z = torch::cat({comm_z, cos_z, sin_z}, 0);
  auto keys = torch::stack({cat_x, cat_z}, 1);

  py::module torch_mod = py::module::import("torch");
  py::tuple uniq_out = torch_mod.attr("unique")(keys, py::arg("dim") = 0, py::arg("return_inverse") = true,
                                               py::arg("sorted") = false)
                          .cast<py::tuple>();
  torch::Tensor uniq = uniq_out[0].cast<torch::Tensor>();
  torch::Tensor inv = uniq_out[1].cast<torch::Tensor>();

  auto new_x = uniq.select(1, 0);
  auto new_z = uniq.select(1, 1);

  auto n_comm = comm_idx.numel();
  auto n_cos = cos_idx.numel();
  auto n_sin = sin_idx.numel();

  auto row_comm = inv.slice(0, 0, n_comm).to(torch::kInt64);
  auto row_cos = inv.slice(0, n_comm, n_comm + n_cos).to(torch::kInt64);
  auto row_sin = inv.slice(0, n_comm + n_cos).to(torch::kInt64);

  auto col_comm = comm_idx;
  auto col_cos = cos_idx;
  auto col_sin = sin_idx;

  std::vector<int64_t> comm_sz{row_comm.numel()};
  std::vector<int64_t> cos_sz{row_cos.numel()};
  auto val_comm = torch::ones(comm_sz, torch::TensorOptions().dtype(coeff_dtype).device(device));
  auto val_cos = torch::ones(cos_sz, torch::TensorOptions().dtype(coeff_dtype).device(device));
  auto val_sin = sin_sign.to(coeff_dtype);

  // Optional coeff cache update via scatter_add (no sparse mm).
  py::object coeffs_cache_out = py::none();
  if (do_prune) {
    std::vector<int64_t> out_sz{new_x.numel()};
    auto out = torch::zeros(out_sz,
                            torch::TensorOptions().dtype(coeffs_prev.dtype()).device(coeffs_prev.device()));
    out.index_add_(0, row_comm, coeffs_prev.index_select(0, col_comm));
    out.index_add_(0, row_cos, coeffs_prev.index_select(0, col_cos) * cos_t);
    out.index_add_(0, row_sin, coeffs_prev.index_select(0, col_sin) * sin_t * sin_sign.to(coeffs_prev.dtype()));
    coeffs_cache_out = py::cast(out);
  }

  // Truncation + row filtering for each matrix.
  auto mask = truncate_terms_mask(new_x, new_z, max_weight, max_xy);
  if (!(mask.all().item<bool>())) {
    auto row_map = torch::cumsum(mask.to(torch::kInt64), 0) - 1;
    auto out_idx = torch::nonzero(mask).flatten().to(torch::kInt64);

    auto filter_triplet = [&](torch::Tensor& row, torch::Tensor& col, torch::Tensor& val) {
      if (row.numel() == 0) {
        return;
      }
      auto keep_rows = mask.index_select(0, row);
      auto keep_idx = torch::nonzero(keep_rows).flatten().to(torch::kInt64);
      row = row.index_select(0, keep_idx);
      col = col.index_select(0, keep_idx);
      val = val.index_select(0, keep_idx);
      row = row_map.index_select(0, row);
    };

    filter_triplet(row_comm, col_comm, val_comm);
    filter_triplet(row_cos, col_cos, val_cos);
    filter_triplet(row_sin, col_sin, val_sin);

    new_x = new_x.index_select(0, out_idx);
    new_z = new_z.index_select(0, out_idx);

    if (do_prune) {
      auto out_coeffs = coeffs_cache_out.cast<torch::Tensor>();
      out_coeffs = out_coeffs.index_select(0, out_idx);
      coeffs_cache_out = py::cast(out_coeffs);
    }
  }

  return std::make_tuple(new_x,
                         new_z,
                         row_comm,
                         col_comm,
                         val_comm,
                         row_cos,
                         col_cos,
                         val_cos,
                         row_sin,
                         col_sin,
                         val_sin,
                         coeffs_cache_out);
}

}  // namespace

PYBIND11_MODULE(_pps_tensor_backend, m) {
  m.def("build_clifford_step_cpp", &build_clifford_step_cpp,
        py::arg("symbol"), py::arg("qubits"), py::arg("x_mask"), py::arg("z_mask"), py::arg("coeff_dtype"),
        py::arg("min_abs") = py::none(), py::arg("coeffs_cache") = py::none(), py::arg("max_weight"), py::arg("max_xy"));

  m.def("build_pauli_rotation_step_cpp", &build_pauli_rotation_step_cpp,
        py::arg("gx"), py::arg("gz"), py::arg("param_idx"), py::arg("x_mask"), py::arg("z_mask"), py::arg("coeff_dtype"),
        py::arg("min_abs") = py::none(), py::arg("coeffs_cache") = py::none(), py::arg("thetas_t") = py::none(),
        py::arg("max_weight"), py::arg("max_xy"));
}
