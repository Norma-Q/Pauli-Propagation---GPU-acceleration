# src_tensor C++ backend

This folder builds a native extension to hide core propagation logic.

## Build (in-place)

From repo root:

```bash
python src_tensor/cpp_backend/setup.py build_ext --inplace
```

This produces a shared library under `src_tensor/` named like:

- `src_tensor/_pps_tensor_backend*.so`

## Notes

- This extension uses PyTorch ATen ops (no custom CUDA kernels). It should work with both CPU and CUDA tensors as long as your installed PyTorch supports CUDA.
- For distribution, ship the compiled `.so` and keep Python wrappers thin.
