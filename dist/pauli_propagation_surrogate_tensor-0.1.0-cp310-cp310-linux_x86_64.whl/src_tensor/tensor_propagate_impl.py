"""Thin wrapper around the compiled tensor propagation backend.

This module intentionally contains *minimal* Python logic so the core
propagation engine can be distributed as a compiled extension.

Dev-only pure Python reference code lives outside the package in:
- dev_backend/tensor_propagate_impl_py.py
- dev_backend/tensor_propagate_impl_full_dev.py

Public API entrypoints remain in `src_tensor/tensor_propagate.py`.
"""

from __future__ import annotations

from typing import Any, Optional, Tuple, TYPE_CHECKING, cast

torch: Any
try:
    import torch as _torch

    torch = _torch
    _TORCH_AVAILABLE = True
except Exception:  # pragma: no cover - optional dependency
    torch = cast(Any, None)
    _TORCH_AVAILABLE = False

if TYPE_CHECKING:
    from torch import Tensor
else:  # pragma: no cover - typing only
    Tensor = Any

torch = cast(Any, torch)

from .tensor_types import TensorSparseStep

_CPP_BACKEND: Any
try:
    from . import _pps_tensor_backend as _CPP_BACKEND  # type: ignore

    _CPP_AVAILABLE = True
except Exception:  # pragma: no cover
    _CPP_BACKEND = cast(Any, None)
    _CPP_AVAILABLE = False


class CPPBackendUnavailableError(RuntimeError):
    pass


def _require_backend() -> None:
    if not _TORCH_AVAILABLE:
        raise RuntimeError("PyTorch is required for tensor propagation.")
    if not _CPP_AVAILABLE:
        raise CPPBackendUnavailableError(
            "Compiled backend is not available. Build it with: "
            "python src_tensor/cpp_backend/setup.py build_ext --inplace"
        )


def _make_sparse(row_idx, col_idx, values, shape, device, dtype):
    if row_idx.numel() == 0:
        return torch.sparse_coo_tensor(
            torch.zeros((2, 0), dtype=torch.int64, device=device),
            torch.zeros((0,), dtype=dtype, device=device),
            size=shape,
            device=device,
            dtype=dtype,
        )
    indices = torch.stack([row_idx, col_idx], dim=0)
    return torch.sparse_coo_tensor(indices, values, size=shape, device=device, dtype=dtype).coalesce()


def _gate_masks(gate) -> Tuple[int, int]:
    gx = 0
    gz = 0
    for q, p in zip(gate.qubits, gate.pauli):
        bit = 1 << int(q)
        if p == "X":
            gx |= bit
        elif p == "Z":
            gz |= bit
        elif p == "Y":
            gx |= bit
            gz |= bit
    return gx, gz


def build_clifford_step(
    *,
    gate,
    x_mask: Tensor,
    z_mask: Tensor,
    t_dtype,
    device: str,
    min_abs: Optional[float],
    coeffs_cache: Optional[Tensor],
    chunk_size: Optional[int],
    chunk_mode: Optional[str],
    max_weight: int,
    max_xy: int,
) -> Tuple[Tensor, Tensor, TensorSparseStep, Optional[Tensor]]:
    _ = (chunk_size, chunk_mode)  # intentionally unused in the C++ backend path
    _require_backend()

    symbol = str(gate.symbol).upper()
    qubits = [int(q) for q in gate.qubits]

    new_x, new_z, row, col, val, coeffs_cache_out = _CPP_BACKEND.build_clifford_step_cpp(
        symbol,
        qubits,
        x_mask,
        z_mask,
        t_dtype,
        min_abs,
        coeffs_cache,
        int(max_weight),
        int(max_xy),
    )

    mat_const = _make_sparse(row, col, val, (new_x.numel(), x_mask.numel()), device, t_dtype)
    mat_empty = _make_sparse(
        torch.zeros(0, dtype=torch.int64, device=device),
        torch.zeros(0, dtype=torch.int64, device=device),
        torch.zeros(0, dtype=t_dtype, device=device),
        (new_x.numel(), x_mask.numel()),
        device,
        t_dtype,
    )

    step = TensorSparseStep(
        mat_const=mat_const,
        mat_cos=mat_empty,
        mat_sin=mat_empty,
        param_idx=-1,
        shape=(new_x.numel(), x_mask.numel()),
    )

    out_cache: Optional[Tensor] = None
    if min_abs is not None and coeffs_cache_out is not None:
        out_cache = cast(Tensor, coeffs_cache_out)

    return new_x, new_z, step, out_cache


def build_pauli_rotation_step(
    *,
    gate,
    x_mask: Tensor,
    z_mask: Tensor,
    t_dtype,
    device: str,
    min_abs: Optional[float],
    coeffs_cache: Optional[Tensor],
    thetas_t: Optional[Tensor],
    chunk_size: Optional[int],
    chunk_mode: Optional[str],
    max_weight: int,
    max_xy: int,
) -> Tuple[Tensor, Tensor, TensorSparseStep, Optional[Tensor]]:
    _ = (chunk_size, chunk_mode)  # intentionally unused in the C++ backend path
    _require_backend()

    gx, gz = _gate_masks(gate)

    (
        new_x,
        new_z,
        r0,
        c0,
        v0,
        r1,
        c1,
        v1,
        r2,
        c2,
        v2,
        coeffs_cache_out,
    ) = _CPP_BACKEND.build_pauli_rotation_step_cpp(
        int(gx),
        int(gz),
        int(gate.param_idx),
        x_mask,
        z_mask,
        t_dtype,
        min_abs,
        coeffs_cache,
        thetas_t,
        int(max_weight),
        int(max_xy),
    )

    mat_const = _make_sparse(r0, c0, v0, (new_x.numel(), x_mask.numel()), device, t_dtype)
    mat_cos = _make_sparse(r1, c1, v1, (new_x.numel(), x_mask.numel()), device, t_dtype)
    mat_sin = _make_sparse(r2, c2, v2, (new_x.numel(), x_mask.numel()), device, t_dtype)

    step = TensorSparseStep(
        mat_const=mat_const,
        mat_cos=mat_cos,
        mat_sin=mat_sin,
        param_idx=int(gate.param_idx),
        shape=(new_x.numel(), x_mask.numel()),
    )

    out_cache: Optional[Tensor] = None
    if min_abs is not None and coeffs_cache_out is not None:
        out_cache = cast(Tensor, coeffs_cache_out)

    return new_x, new_z, step, out_cache


__all__ = [
    "CPPBackendUnavailableError",
    "build_clifford_step",
    "build_pauli_rotation_step",
]
