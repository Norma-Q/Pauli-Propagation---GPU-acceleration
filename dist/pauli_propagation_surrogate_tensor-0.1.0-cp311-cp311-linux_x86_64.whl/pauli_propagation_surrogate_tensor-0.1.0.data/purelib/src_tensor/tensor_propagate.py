"""Tensor-native surrogate propagation (GPU-first, WIP)."""

from __future__ import annotations

from typing import Any, List, Optional, Tuple, TYPE_CHECKING, cast

torch: Any
try:
    import torch as _torch
    torch = _torch
    _TORCH_AVAILABLE = True
except Exception:  # pragma: no cover - optional dependency
    torch = cast(Any, None)
    _TORCH_AVAILABLE = False

if TYPE_CHECKING:
    from torch import Tensor
else:  # pragma: no cover - typing only
    Tensor = Any

torch = cast(Any, torch)

from .tensor_types import TensorPauliSum, TensorSparseStep
from tqdm import tqdm

from .tensor_propagate_impl import (
    build_clifford_step,
    build_pauli_rotation_step,
)


def _make_sparse(row_idx, col_idx, values, shape, device, dtype):
    if row_idx.numel() == 0:
        return torch.sparse_coo_tensor(
            torch.zeros((2, 0), dtype=torch.int64, device=device),
            torch.zeros((0,), dtype=dtype, device=device),
            size=shape,
            device=device,
            dtype=dtype,
        )
    indices = torch.stack([row_idx, col_idx], dim=0)
    return torch.sparse_coo_tensor(indices, values, size=shape, device=device, dtype=dtype).coalesce()


def make_selection_step(row_mask: Tensor, n_in: int, device, dtype) -> TensorSparseStep:
    col_idx = torch.nonzero(row_mask, as_tuple=False).flatten()
    row_idx = torch.arange(col_idx.numel(), dtype=torch.int64, device=device)
    val = torch.ones_like(row_idx, dtype=dtype, device=device)
    mat_const = _make_sparse(row_idx, col_idx, val, (row_idx.numel(), n_in), device, dtype)
    mat_empty = _make_sparse(
        torch.zeros(0, dtype=torch.int64, device=device),
        torch.zeros(0, dtype=torch.int64, device=device),
        torch.zeros(0, dtype=dtype, device=device),
        (row_idx.numel(), n_in),
        device,
        dtype,
    )
    return TensorSparseStep(
        mat_const=mat_const,
        mat_cos=mat_empty,
        mat_sin=mat_empty,
        param_idx=-1,
        shape=(row_idx.numel(), n_in),
    )


def _sparse_used_cols(mat: Tensor, row_mask: Tensor, n_cols: int) -> Tensor:
    mat = mat.coalesce()
    if mat._nnz() == 0 or row_mask.sum() == 0:
        return torch.zeros((n_cols,), dtype=torch.bool, device=mat.device)
    row_idx, col_idx = mat.indices()
    keep = row_mask[row_idx]
    if keep.any():
        used = torch.zeros((n_cols,), dtype=torch.bool, device=mat.device)
        used[col_idx[keep]] = True
        return used
    return torch.zeros((n_cols,), dtype=torch.bool, device=mat.device)


def _filter_sparse_rows_cols(mat: Tensor, row_mask: Tensor, col_mask: Tensor) -> Tensor:
    mat = mat.coalesce()
    new_shape = (int(row_mask.sum().item()), int(col_mask.sum().item()))
    if mat._nnz() == 0 or new_shape[0] == 0 or new_shape[1] == 0:
        return torch.sparse_coo_tensor(
            torch.zeros((2, 0), dtype=torch.int64, device=mat.device),
            torch.zeros((0,), dtype=mat.dtype, device=mat.device),
            size=new_shape,
            device=mat.device,
            dtype=mat.dtype,
        )
    row_idx, col_idx = mat.indices()
    val = mat.values()
    keep = row_mask[row_idx] & col_mask[col_idx]
    row_idx = row_idx[keep]
    col_idx = col_idx[keep]
    val = val[keep]
    if row_idx.numel() == 0:
        return torch.sparse_coo_tensor(
            torch.zeros((2, 0), dtype=torch.int64, device=mat.device),
            torch.zeros((0,), dtype=mat.dtype, device=mat.device),
            size=new_shape,
            device=mat.device,
            dtype=mat.dtype,
        )
    row_map = torch.cumsum(row_mask.to(torch.int64), dim=0) - 1
    col_map = torch.cumsum(col_mask.to(torch.int64), dim=0) - 1
    row_idx = row_map[row_idx]
    col_idx = col_map[col_idx]
    return torch.sparse_coo_tensor(
        torch.stack([row_idx, col_idx], dim=0),
        val,
        size=new_shape,
        device=mat.device,
        dtype=mat.dtype,
    ).coalesce()


def _filter_step_rows_cols(step: TensorSparseStep, row_mask: Tensor, col_mask: Tensor) -> TensorSparseStep:
    new_const = _filter_sparse_rows_cols(step.mat_const, row_mask, col_mask)
    new_cos = _filter_sparse_rows_cols(step.mat_cos, row_mask, col_mask)
    new_sin = _filter_sparse_rows_cols(step.mat_sin, row_mask, col_mask)
    return TensorSparseStep(
        mat_const=new_const,
        mat_cos=new_cos,
        mat_sin=new_sin,
        param_idx=step.param_idx,
        shape=(int(row_mask.sum().item()), int(col_mask.sum().item())),
    )

 


def _step_to_device(step: TensorSparseStep, device: str) -> TensorSparseStep:
    return TensorSparseStep(
        mat_const=step.mat_const.to(device),
        mat_cos=step.mat_cos.to(device),
        mat_sin=step.mat_sin.to(device),
        param_idx=step.param_idx,
        shape=step.shape,
    )


def propagate_surrogate_tensor(
    circuit,
    observable,
    max_weight: int = 1000,
    max_xy: int = 1000,
    device: str = "cuda",
    dtype: str = "float64",
    thetas: Optional[Tensor] = None,
    min_abs: Optional[float] = None,
    offload_steps: Optional[bool] = None,
    offload_keep: int = 2,
    chunk_size: Optional[int] = None,
    chunk_mode: Optional[str] = None,
) -> TensorPauliSum:
    """Tensor-native propagation to a tensor PauliSum.

    NOTE: This version supports up to 63 qubits (int64 bitmasks).
    """
    if not _TORCH_AVAILABLE:
        raise RuntimeError("PyTorch is required for tensor propagation.")
    if min_abs is not None and thetas is None:
        raise ValueError("min_abs requires thetas to be provided.")

    if offload_steps is None:
        offload_steps = device != "cpu"

    n_qubits = observable.n_qubits
    if n_qubits > 63:
        raise NotImplementedError("tensor propagation supports n_qubits <= 63")

    # Build initial tensors from observable
    pstrs = list(observable.terms.keys())
    coeffs = [float(observable.terms[p]) for p in pstrs]

    x_mask = torch.as_tensor([p.x_mask for p in pstrs], dtype=torch.int64, device=device)
    z_mask = torch.as_tensor([p.z_mask for p in pstrs], dtype=torch.int64, device=device)

    t_dtype = torch.float64 if dtype == "float64" else torch.float32
    coeff_init = torch.as_tensor(coeffs, dtype=t_dtype, device=device)
    steps: List[TensorSparseStep] = []

    coeffs_cache: Optional[Tensor] = None
    thetas_t: Optional[Tensor] = None

    if min_abs is not None:
        coeffs_cache = coeff_init
        thetas_t = torch.as_tensor(thetas, dtype=coeff_init.dtype, device=device)
        assert thetas_t is not None
        if thetas_t.numel() == 0:
            thetas_t = torch.zeros(1, dtype=coeff_init.dtype, device=device)

    for gate in tqdm(reversed(circuit), total=len(circuit), desc="propagate", dynamic_ncols=True):
        gate_name = gate.__class__.__name__
        if gate_name == "CliffordGate":
            new_x, new_z, step, coeffs_cache = build_clifford_step(
                gate=gate,
                x_mask=x_mask,
                z_mask=z_mask,
                t_dtype=t_dtype,
                device=device,
                min_abs=min_abs,
                coeffs_cache=coeffs_cache,
                chunk_size=chunk_size,
                chunk_mode=chunk_mode,
                max_weight=max_weight,
                max_xy=max_xy,
            )

            steps.append(step)
            if offload_steps and device != "cpu" and len(steps) > offload_keep:
                idx = len(steps) - offload_keep - 1
                if steps[idx].mat_const.device.type != "cpu":
                    steps[idx] = _step_to_device(steps[idx], "cpu")
            x_mask, z_mask = new_x, new_z
            continue

        if gate_name == "PauliRotation":
            new_x, new_z, step, coeffs_cache = build_pauli_rotation_step(
                gate=gate,
                x_mask=x_mask,
                z_mask=z_mask,
                t_dtype=t_dtype,
                device=device,
                min_abs=min_abs,
                coeffs_cache=coeffs_cache,
                thetas_t=thetas_t,
                chunk_size=chunk_size,
                chunk_mode=chunk_mode,
                max_weight=max_weight,
                max_xy=max_xy,
            )

            steps.append(step)
            if offload_steps and device != "cpu" and len(steps) > offload_keep:
                idx = len(steps) - offload_keep - 1
                if steps[idx].mat_const.device.type != "cpu":
                    steps[idx] = _step_to_device(steps[idx], "cpu")
            x_mask, z_mask = new_x, new_z

    psum = TensorPauliSum(
        n_qubits=n_qubits,
        x_mask=x_mask,
        z_mask=z_mask,
        coeff_init=coeff_init,
        steps=steps,
    )

    return psum


def zero_filter_tensor(psum: TensorPauliSum) -> TensorPauliSum:
    """Filter to x_mask == 0 (diagonal terms only)."""
    if not _TORCH_AVAILABLE:
        raise RuntimeError("PyTorch is required for tensor backend.")
    mask = psum.x_mask == 0
    steps = list(psum.steps)
    if not torch.all(mask):
        t_dtype = psum.coeff_init.dtype
        steps.append(make_selection_step(mask, psum.x_mask.numel(), psum.x_mask.device, t_dtype))
    return TensorPauliSum(
        n_qubits=psum.n_qubits,
        x_mask=psum.x_mask[mask],
        z_mask=psum.z_mask[mask],
        coeff_init=psum.coeff_init,
        steps=steps,
    )


def zero_filter_tensor_backprop(
    psum: TensorPauliSum,
    stream_device: Optional[str] = None,
    offload_back: Optional[bool] = None,
) -> TensorPauliSum:
    """Back-propagating zero-filter (prune rows/cols through sparse steps)."""
    if not _TORCH_AVAILABLE:
        raise RuntimeError("PyTorch is required for tensor backend.")
    if psum.x_mask.numel() == 0:
        return psum

    out_mask = psum.x_mask == 0
    steps = list(psum.steps)

    if stream_device is None:
        stream_device = psum.x_mask.device.type if psum.x_mask.device.type != "cpu" else None
    if offload_back is None:
        offload_back = stream_device is not None

    row_mask = out_mask
    for i in reversed(range(len(steps))):
        step = steps[i]
        if stream_device is not None and step.mat_const.device.type != stream_device:
            step = _step_to_device(step, stream_device)

        n_cols = step.shape[1]
        row_mask_device = row_mask.to(step.mat_const.device)
        col_mask = _sparse_used_cols(step.mat_const, row_mask_device, n_cols)
        col_mask |= _sparse_used_cols(step.mat_cos, row_mask_device, n_cols)
        col_mask |= _sparse_used_cols(step.mat_sin, row_mask_device, n_cols)

        steps[i] = _filter_step_rows_cols(step, row_mask_device, col_mask)
        row_mask = col_mask.to(out_mask.device)

        if stream_device is not None and offload_back:
            steps[i] = _step_to_device(steps[i], "cpu")

    coeff_init = psum.coeff_init[row_mask]

    return TensorPauliSum(
        n_qubits=psum.n_qubits,
        x_mask=psum.x_mask[out_mask],
        z_mask=psum.z_mask[out_mask],
        coeff_init=coeff_init,
        steps=steps,
    )


__all__ = [
    "propagate_surrogate_tensor",
    "zero_filter_tensor",
    "zero_filter_tensor_backprop",
]
